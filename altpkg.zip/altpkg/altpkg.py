from api import *
import os, sys, json, time
from distutils.dir_util import copy_tree as copy_folder, remove_tree as rmdir


def getpkg(pack):
    url = f"{pack}.zip"
    packdir = f"{config['tempdir']}/{pack}"
    zippath = f"{packdir}/pkg.zip"
    try:
        os.makedirs(packdir)
    except FileExistsError:
        pass
    try:
        download(url, zippath)
    except:
        print("Unknown package:", pack)
        exit(1)
    print(zippath)
    unzip(zippath)
    os.remove(zippath)


with open("altcfg.json", "rt") as f:
    config = json.load(f)


pkg = sys.argv[-1]

real = isinrepo(pkg)

if not real:
    print("Unknown package")
    sys.exit()

print("Package found")

packdir = os.path.expanduser(f"{config['tempdir']}/{pkg}")

try:
    os.makedirs(packdir)
except:pass

print("Downloading", pkg)

getpkg(pkg)

print("Reading for package header")


with open(packdir+"/"+pkg+"/altpackage.json", "rt") as f:
    cfg = json.load(f)

print("Reading metadata")

if cfg["packname"] != pkg:
    print("Corrupted package file")
    sys.exit()

print("Analysing metadata")

bits = "64bit" if sys.maxsize > 2**32 else "32bit"

print("Machine is", bits)

sup32, sup64 = cfg["32bit"] != ".", cfg["64bit"] != "."

if bits == "32bit" and not sup32:
    print("Package not supported")
    sys.exit()
if bits == "32bit" and sup32:
    bitness = "x86"
if bits == "64bit" and sup64:
    bitness = "x64"
if bits == "64bits" and not sup64:
    bitness = "x86"

realdir = os.path.expanduser(config["appsdir"]+"/"+pkg)

copy_folder(packdir+"/"+pkg+"/"+bitness, realdir)
f = open(os.path.expanduser(config[".bashrc"]), "at")
print(f"PATH={realdir}:$PATH", file=f)
f.close()

#os.system(f"echo 'PATH={realdir}/{pkg}:$PATH' >> ~/bashrc")


#f = open("etc/environment", "at")
#f.write()

print("Successfully installed \""+pkg+"\"")

os.chdir(realdir)

exec(cfg["post"].replace("{realpath}", realdir))

try:
    rmdir("__pycache__")
except: pass

try:
    rmdir(config["tempdir"])
except: pass

print("Machine should be restarted. Please, save your work and reboot the machine")