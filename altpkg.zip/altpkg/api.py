import requests
import tarfile
import time
import zipfile
import json


with open("altcfg.json", "rt") as f:
    config = json.load(f)


def downloadFile(url, adr):
    frames = ["/", "-", "\\", "|"]
    max_frames = 3
    current_frame = 0
    with open(adr, 'wb') as f:
        start = time.time()
        r = requests.get(url, stream=True)
        total_length = int(r.headers.get('content-length')) if r.headers.get('content-length') is not None else None
        dl = 0
        if total_length is None:
            f.write(r.content)
        else:
            for chunk in r.iter_content(1024):
                dl += len(chunk)
                f.write(chunk)
                done = int(50 * dl / total_length)
                dat = ("="*done, " "*(50-done), frames[current_frame], dl//(time.time() - start)//1024)
                #current_frame += 1
                print("Process [%s%s] %c %d kb/s   " % dat, end="\r")
    print()


def download(path, adr,
             root=config["repository"],
             post=config["postfix"]):
    downloadFile(root+path+post, adr)


def isinrepo(pkg,
             root=config["repository"],
             post=config["postfix"]):
    r = requests.head(root+pkg+".zip"+post)
    return r.status_code < 400


def unzip(fname):
    with zipfile.ZipFile(fname, 'r') as zip_ref:
        zip_ref.extractall(fname[:-len("/"+fname.split("/")[-1])])
